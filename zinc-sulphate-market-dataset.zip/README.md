# Zinc Sulphate Market Dataset (MC3561)

This dataset contains structured, non-proprietary information extracted from the public landing page of the Zinc Sulphate Market report (MC3561) on NextMSC.

Contents:
- metadata.json
- summary.txt
- segments.csv
- companies.csv
- table_of_contents.md
- license.txt

Data includes only publicly available information and does not contain paid report content.
